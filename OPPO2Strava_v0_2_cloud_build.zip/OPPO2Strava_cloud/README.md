# OPPO2Strava V0.2

Cloud-buildable Android test app.

- OnePlus 13 / ColorOS 16 target
- User selects the Download folder using Android Storage Access Framework
- Periodic WorkManager scan
- Finds `.fit` files
- SHA-256 deduplication
- No Strava upload yet

V0.3 will add Strava OAuth and upload.
