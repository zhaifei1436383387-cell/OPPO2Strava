package com.oppo2strava

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.documentfile.provider.DocumentFile
import java.security.MessageDigest

class FitScanWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext.getSharedPreferences("app", Context.MODE_PRIVATE)
        val folder = app.getString("folder_uri", null) ?: return Result.success()

        val children = DocumentFile.fromTreeUri(
            applicationContext, Uri.parse(folder)
        )?.listFiles() ?: return Result.success()

        val seen = applicationContext.getSharedPreferences("seen", Context.MODE_PRIVATE)
        for (file in children) {
            if (!file.isFile || !file.name.orEmpty().lowercase().endsWith(".fit")) continue

            val digest = sha256(file.uri)
            if (!seen.getBoolean(digest, false)) {
                // V0.2: only records discovery. V0.3 will upload to Strava.
                seen.edit().putBoolean(digest, true).apply()
            }
        }
        return Result.success()
    }

    private fun sha256(uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        applicationContext.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input)
            val buf = ByteArray(8192)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
