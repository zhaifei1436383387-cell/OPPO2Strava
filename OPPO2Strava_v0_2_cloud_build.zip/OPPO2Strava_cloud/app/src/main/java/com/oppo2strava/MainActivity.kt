package com.oppo2strava

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        getSharedPreferences("app", MODE_PRIVATE)
            .edit().putString("folder_uri", uri.toString()).apply()
        status.text = "已选择文件夹\n$uri\n\n后台扫描已开启"
        scheduleScan()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        val title = TextView(this).apply {
            text = "OPPO2Strava"
            textSize = 28f
        }

        status = TextView(this).apply {
            textSize = 16f
            text = "请选择运动健康导出的 FIT 文件所在文件夹。\n\n建议选择 Download。"
            setPadding(0, 32, 0, 32)
        }

        val choose = Button(this).apply {
            text = "选择 FIT 文件夹"
            setOnClickListener { folderPicker.launch(null) }
        }

        val battery = Button(this).apply {
            text = "打开电池优化设置"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(choose)
        root.addView(battery)
        setContentView(root)

        if (getSharedPreferences("app", MODE_PRIVATE).contains("folder_uri")) {
            status.text = "已选择文件夹，后台扫描已开启。"
            scheduleScan()
        }
    }

    private fun scheduleScan() {
        val request = PeriodicWorkRequestBuilder<FitScanWorker>(
            15, TimeUnit.MINUTES
        ).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "fit_scan",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
